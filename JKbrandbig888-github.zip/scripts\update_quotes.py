import json
import pathlib
import urllib.parse
import urllib.request
from datetime import datetime, timezone

SYMBOLS = {
    "2330": "2330.TW", "2454": "2454.TW", "2881": "2881.TW",
    "AAPL": "AAPL", "NVDA": "NVDA", "MSFT": "MSFT",
}


def fetch_quote(symbol, provider_symbol):
    encoded = urllib.parse.quote(provider_symbol)
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{encoded}?interval=1m&range=1d"
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=20) as response:
        result = json.load(response)["chart"]["result"][0]
    meta = result["meta"]
    price = float(meta["regularMarketPrice"])
    previous = float(meta.get("chartPreviousClose") or meta.get("previousClose") or price)
    change = round((price - previous) / previous * 100, 2) if previous else 0
    return {"symbol": symbol, "price": price, "change": change,
            "currency": meta.get("currency"), "marketState": meta.get("marketState")}


quotes = []
errors = []
for symbol, provider_symbol in SYMBOLS.items():
    try:
        quotes.append(fetch_quote(symbol, provider_symbol))
    except Exception as exc:
        errors.append({"symbol": symbol, "message": str(exc)[:160]})

if not quotes:
    raise RuntimeError("No quotes could be updated")

output = pathlib.Path("data/quotes.json")
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps({
    "updatedAt": datetime.now(timezone.utc).isoformat(),
    "source": "GitHub Actions delayed market data",
    "quotes": quotes,
    "errors": errors,
}, ensure_ascii=False, indent=2), encoding="utf-8")
