const symbols={'2330':'2330.TW','2454':'2454.TW','2881':'2881.TW','AAPL':'AAPL','NVDA':'NVDA','MSFT':'MSFT'};

exports.handler=async function(){
  try{
    const quotes=await Promise.all(Object.entries(symbols).map(async([symbol,providerSymbol])=>{
      const url=`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(providerSymbol)}?interval=1m&range=1d`;
      const response=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0'}});
      if(!response.ok)throw new Error(`Quote failed: ${symbol}`);
      const result=(await response.json()).chart.result?.[0];
      const meta=result?.meta||{},price=Number(meta.regularMarketPrice),previous=Number(meta.chartPreviousClose||meta.previousClose);
      return {symbol,price,change:previous?Number(((price-previous)/previous*100).toFixed(2)):0,currency:meta.currency,marketState:meta.marketState};
    }));
    return {statusCode:200,headers:{'content-type':'application/json; charset=utf-8','cache-control':'public, max-age=30'},body:JSON.stringify({updatedAt:new Date().toISOString(),quotes})};
  }catch(error){return {statusCode:502,headers:{'content-type':'application/json; charset=utf-8'},body:JSON.stringify({error:'行情來源暫時無法使用'})}}
};
